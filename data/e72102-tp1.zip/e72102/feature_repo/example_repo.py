from datetime import timedelta

import pandas as pd

from feast import (
    Entity,
    FeatureService,
    FeatureView,
    Field,
    FileSource,
    Project,
    PushSource,
    RequestSource,
)
from feast.feature_logging import LoggingConfig
from feast.infra.offline_stores.file_source import FileLoggingDestination
from feast.on_demand_feature_view import on_demand_feature_view
from feast.types import Float32, Float64, Int64, String, UnixTimestamp
from feast.value_type import ValueType

project = Project(name="e72102", description="A project for working with automobile data")

automobile = Entity(name="car", value_type=ValueType.INT64, join_keys=["id"])

automobile_raw = FileSource(
    name="automobile_raw",
    path="data/automobile_raw.parquet",
    timestamp_field="timestamp"
)

automobile_raw_features = FeatureView(
    name="automobile_raw_features",
    entities=[automobile],
    schema=[
        Field(name="id", dtype=Int64),
        Field(name="timestamp", dtype=UnixTimestamp),
        Field(name="symboling", dtype=Int64),
        Field(name="normalized-losses", dtype=Float64),
        Field(name="make", dtype=String),
        Field(name="fuel-type", dtype=String),
        Field(name="aspiration", dtype=String),
        Field(name="num-of-doors", dtype=String),
        Field(name="body-style", dtype=String),
        Field(name="drive-wheels", dtype=String),
        Field(name="engine-location", dtype=String),
        Field(name="wheel-base", dtype=Float64),
        Field(name="length", dtype=Float64),
        Field(name="width", dtype=Float64),
        Field(name="height", dtype=Float64),
        Field(name="curb-weight", dtype=Int64),
        Field(name="engine-type", dtype=String),
        Field(name="num-of-cylinders", dtype=String),
        Field(name="engine-size", dtype=Int64),
        Field(name="fuel-system", dtype=String),
        Field(name="bore", dtype=Float64),
        Field(name="stroke", dtype=Float64),
        Field(name="compression-ratio", dtype=Float64),
        Field(name="horsepower", dtype=Int64),
        Field(name="peak-rpm", dtype=Int64),
        Field(name="city-mpg", dtype=Int64),
        Field(name="highway-mpg", dtype=Int64),
        Field(name="price", dtype=Float64),
    ],
    online=False,
    source=automobile_raw,
    tags={"source": "automobile"},
)

automobile_prepared = FileSource(
    name="automobile_prepared",
    path="data/automobile_prepared.parquet",
    timestamp_field="timestamp"
)

automobile_prepared_features = FeatureView(
    name="automobile_prepared_features",
    entities=[automobile],
    schema=[
        Field(name="id", dtype=Int64),
        Field(name="timestamp", dtype=UnixTimestamp),
        Field(name="wheel-base", dtype=Float64),
        Field(name="length", dtype=Float64),
        Field(name="width", dtype=Float64),
        Field(name="height", dtype=Float64),
        Field(name="curb-weight", dtype=Int64),
        Field(name="engine-size", dtype=Int64),
        Field(name="bore", dtype=Float64),
        Field(name="stroke", dtype=Float64),
        Field(name="compression-ratio", dtype=Float64),
        Field(name="horsepower", dtype=Int64),
        Field(name="peak-rpm", dtype=Int64),
        Field(name="city-mpg", dtype=Int64),
        Field(name="highway-mpg", dtype=Int64),
        Field(name="make", dtype=Int64),
        Field(name="fuel-type", dtype=Int64),
        Field(name="aspiration", dtype=Int64),
        Field(name="num-of-doors", dtype=Int64),
        Field(name="body-style", dtype=Int64),
        Field(name="drive-wheels", dtype=Int64),
        Field(name="engine-location", dtype=Int64),
        Field(name="engine-type", dtype=Int64),
        Field(name="num-of-cylinders", dtype=Int64),
        Field(name="fuel-system", dtype=Int64),
        Field(name="lnprice", dtype=Float64),
    ],
    online=False,
    source=automobile_prepared,
    tags={"source": "automobile"},
)